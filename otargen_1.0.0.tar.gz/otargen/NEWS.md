# otargen 1.0.0

* This is the first release of otargen.
